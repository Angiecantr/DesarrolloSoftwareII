import { Component } from '@angular/core';

@Component({
  selector: 'app-planets-page',
  imports: [],
  templateUrl: './planets-page.html',
  styles: ``
})
export default class PlanetsPage {

}
