import { Component } from '@angular/core';

@Component({
  selector: 'app-people-page',
  imports: [],
  templateUrl: './people-page.html',
  styles: ``
})
export default class PeoplePage {

}
