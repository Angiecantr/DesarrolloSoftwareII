import { Component } from '@angular/core';

@Component({
  selector: 'app-movies-page',
  imports: [],
  templateUrl: './movies-page.html',
  styles: ``
})
export default class MoviesPage {

}
