export const environment = {
    production: false,
    companyName: 'Starwars',
    companyNeme2: 'Apps',
    companySlogan: 'Mundo de Starwars',

};
