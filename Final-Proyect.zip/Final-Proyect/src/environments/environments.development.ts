export const environment = {
    production: true,
    companyName: 'Starwars',
    companyNeme2: 'Apps',
    companySlogan: 'Mundo de Starwars',

};
